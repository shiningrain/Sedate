# CodeQL 2.23.8 default-suite scan

Scan configuration:

- CodeQL CLI: 2.23.8
- Language: C/C++ (`cpp`)
- Database build mode: `none`
- Query suite: `codeql/cpp-queries:codeql-suites/cpp-code-scanning.qls`
- Query pack: `codeql/cpp-queries` 1.5.7
- Queries run per repository: 56
- Output format: SARIF 2.1.0

The 491-query figure in the CodeQL 2.23.8 release notes is the total for the
Default suite across all supported languages. The C/C++ Default suite selected
56 queries for these repositories.

## Results

| Repository | Version | C/C++ coverage | Results |
| --- | --- | ---: | ---: |
| HTMLDOC | v1.9.22 | 37 / 41 | 2 |
| ImageMagick | 7.1.2-10 | 680 / 704 | 12 |
| libvips | v8.18.0 | 572 / 582 | 0 |

### HTMLDOC

| Rule | Severity | Security score | Location |
| --- | --- | ---: | --- |
| `cpp/weak-cryptographic-algorithm` | error | 7.5 | `htmldoc/ps-pdf.cxx:10823` |
| `cpp/wrong-number-format-arguments` | error | 5.0 | `htmldoc/ps-pdf.cxx:2408` |

### ImageMagick

| Rule | Severity | Security score | Count | Locations |
| --- | --- | ---: | ---: | --- |
| `cpp/tainted-format-string` | warning | 9.3 | 2 | `MagickCore/image.c:1745`, `MagickWand/wandcli.c:284` |
| `cpp/wrong-number-format-arguments` | error | 5.0 | 10 | Under `www/source/` (example/documentation source) |

### libvips

No results were produced by the C/C++ Default suite.

## Artifacts

- `htmldoc-default.sarif`
- `imagemagick-default.sarif`
- `libvips-default.sarif`
- `databases/`: reusable CodeQL databases
- `logs/`: database creation and analysis logs

Results are static-analysis findings and require manual triage before being
treated as confirmed vulnerabilities. Build mode `none` scans source without
using each project's real build configuration; it improves portability but can
reduce configuration-specific precision.

## Maximum-coverage follow-up

To maximize findings, a second pass combined these suites:

- `cpp-security-and-quality.qls`: 181 stable security and quality queries
- `cpp-security-experimental.qls`: 134 experimental security queries
- Overlap: 97 queries
- Combined total after deduplication: 218 queries per repository

| Repository | Total results | Errors | Warnings | Notes | Triggered rules |
| --- | ---: | ---: | ---: | ---: | ---: |
| HTMLDOC | 190 | 10 | 33 | 147 | 24 |
| ImageMagick | 4,070 | 212 | 1,195 | 2,663 | 41 |
| libvips | 3,187 | 1 | 1,405 | 1,781 | 35 |

Combined reports:

- `htmldoc-maximum.sarif`
- `imagemagick-maximum.sarif`
- `libvips-maximum.sarif`

The stable-only and experimental-suite reports are also retained separately.
Many ImageMagick and libvips results come from parsing without their generated
build configuration, especially implicit declarations and argument-type
diagnostics. The maximum reports intentionally favor breadth over precision.
